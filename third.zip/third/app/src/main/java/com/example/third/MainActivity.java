package com.example.third;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
    FirstFragment one;
    SecondFragment two;
    int showingFragment=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        one= new FirstFragment();
        two= new SecondFragment();



    }
     public  void switchFragment(View view)
     {
         FragmentManager fmgr=getSupportFragmentManager();
         FragmentTransaction ft= fmgr.beginTransaction();

         if(showingFragment==1)
         {
             ft.replace(R.id.one,two);
             showingFragment=2;
         }
         else
         {
             ft.replace(R.id.one,one);
             showingFragment=1;
         }
         ft.commit();
     }
}